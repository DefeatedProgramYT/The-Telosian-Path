# The Telosian Path - Integrated Wellness Dashboard

## Overview
A comprehensive wellness and productivity dashboard built as a single-page React application with Firebase Firestore integration. The application provides three main modules for complete personal management.

## Features

### 📝 Document Writer (LibreOffice Writer Style)
- Rich text editing with formatting options
- Auto-save functionality
- Document title and content management
- Persistent storage in Firestore

### 💪 Health & Calculation Module
- **Health Tracking:**
  - Daily steps tracking with goal setting
  - Sleep duration monitoring
  - Water intake tracking
  - Visual progress bars
- **Exercise Tracker:**
  - Add daily exercises with name, duration, and intensity
  - Total exercise time calculation
  - Exercise history for the day
- **Calculator:**
  - Four-function calculator (+, -, *, /)
  - Professional UI with responsive design

### 📚 Daily Journal & Learning
- **Daily Journal:**
  - Rich text journal entries
  - Date-based organization
  - Auto-save functionality
- **Learning Challenges:**
  - Daily rotating topics (8 different subjects)
  - Two learning sessions per day
  - Progress tracking and completion status
  - Public/shared challenge system

## Technical Implementation

### Architecture
- **Single File Structure:** All functionality implemented in one React component (App.jsx)
- **State Management:** React hooks (useState, useEffect) for local state
- **Data Persistence:** Firebase Firestore for all user data
- **Real-time Updates:** onSnapshot listeners for live data synchronization

### Styling
- **Tailwind CSS:** Utility-first CSS framework
- **Responsive Design:** Mobile-first approach with sm:, md:, lg: breakpoints
- **Modern UI:** Glass effects, gradients, and smooth animations
- **Professional Aesthetics:** Clean design with proper spacing and typography

### Firebase Integration
- **Authentication:** Custom token-based authentication
- **Data Structure:**
  - `/artifacts/{appId}/users/{userId}/documents/` - User documents
  - `/artifacts/{appId}/users/{userId}/health/` - Health metrics
  - `/artifacts/{appId}/users/{userId}/exercises/` - Exercise logs
  - `/artifacts/{appId}/users/{userId}/journal_entries/` - Journal entries
  - `/artifacts/{appId}/public/data/daily_challenges/` - Shared challenges

## File Structure
```
/mnt/okcomputer/output/
├── index.html              # Main HTML file with embedded React app
├── App.jsx                 # Complete React application (source)
├── package.json            # Project dependencies
├── tailwind.config.js      # Tailwind CSS configuration
├── vite.config.js          # Vite build configuration
└── src/
    ├── main.jsx           # React entry point
    └── index.css          # Global styles
```

## Usage

### Running the Application
1. **Development Mode:**
   ```bash
   cd /mnt/okcomputer/output
   npm install
   npm run dev
   ```

2. **Production Build:**
   ```bash
   npm run build
   npm run preview
   ```

### Navigation
- Use the sidebar to switch between modules
- Document Writer: Create and edit documents
- Health & Calc: Track wellness metrics and use calculator
- Daily Journal: Write journals and complete learning challenges

### Data Management
- All data auto-saves to Firebase Firestore
- Real-time synchronization across devices
- Offline capability with Firestore offline persistence

## Key Features Implemented

✅ **Responsive Design:** Works on mobile, tablet, and desktop
✅ **Auto-save:** All content saves automatically
✅ **Real-time Updates:** Live data synchronization
✅ **Professional UI:** Modern design with smooth animations
✅ **Error Handling:** Comprehensive error boundaries and try-catch blocks
✅ **Loading States:** Clear loading indicators during data fetching
✅ **Accessibility:** Proper ARIA labels and keyboard navigation
✅ **Performance:** Optimized rendering and efficient data updates

## Customization

### Firebase Configuration
Update the Firebase config in the JavaScript section:
```javascript
const firebaseConfig = {
    apiKey: "your-api-key",
    authDomain: "your-auth-domain",
    projectId: "your-project-id",
    // ... other config
};
```

### Styling
Modify Tailwind classes in the HTML/React components to customize:
- Colors (primary, secondary color schemes)
- Spacing and layout
- Typography and fonts
- Animation effects

### Learning Topics
Update the `learningTopics` array in the Daily Rotation module to customize learning content.

## Browser Support
- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance
- Lazy loading of module content
- Efficient re-rendering with React hooks
- Optimized Firebase queries with proper indexing
- Minimal bundle size with tree shaking

---

**The Telosian Path** - Your comprehensive companion for wellness, productivity, and continuous learning.